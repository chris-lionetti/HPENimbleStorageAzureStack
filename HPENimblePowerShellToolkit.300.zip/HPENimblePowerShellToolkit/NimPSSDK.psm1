. $PSScriptRoot\scripts\helpers.ps1
. $PSScriptRoot\scripts\VolumeCollection.ps1
. $PSScriptRoot\scripts\AccessControlRecord.ps1
. $PSScriptRoot\scripts\Token.ps1
. $PSScriptRoot\scripts\UserGroup.ps1
. $PSScriptRoot\scripts\ChapUser.ps1
. $PSScriptRoot\scripts\Witness.ps1
. $PSScriptRoot\scripts\Pool.ps1
. $PSScriptRoot\scripts\FibreChannelInitiatorAlias.ps1
. $PSScriptRoot\scripts\ProtectionTemplate.ps1
. $PSScriptRoot\scripts\InitiatorGroup.ps1
. $PSScriptRoot\scripts\Snapshot.ps1
. $PSScriptRoot\scripts\Volume.ps1
. $PSScriptRoot\scripts\ActiveDirectoryMembership.ps1
. $PSScriptRoot\scripts\Subnet.ps1
. $PSScriptRoot\scripts\SpaceDomain.ps1
. $PSScriptRoot\scripts\Group.ps1
. $PSScriptRoot\scripts\ReplicationPartner.ps1
. $PSScriptRoot\scripts\Folder.ps1
. $PSScriptRoot\scripts\NetworkConfig.ps1
. $PSScriptRoot\scripts\Controller.ps1
. $PSScriptRoot\scripts\ProtectionSchedule.ps1
. $PSScriptRoot\scripts\MasterKey.ps1
. $PSScriptRoot\scripts\Event.ps1
. $PSScriptRoot\scripts\ApplicationServer.ps1
. $PSScriptRoot\scripts\FibreChannelPort.ps1
. $PSScriptRoot\scripts\ApplicationCategory.ps1
. $PSScriptRoot\scripts\AuditLog.ps1
. $PSScriptRoot\scripts\Initiator.ps1
. $PSScriptRoot\scripts\Version.ps1
. $PSScriptRoot\scripts\PerformancePolicy.ps1
. $PSScriptRoot\scripts\Job.ps1
. $PSScriptRoot\scripts\Disk.ps1
. $PSScriptRoot\scripts\NetworkInterface.ps1
. $PSScriptRoot\scripts\UserPolicy.ps1
. $PSScriptRoot\scripts\SoftwareVersion.ps1
. $PSScriptRoot\scripts\SnapshotCollection.ps1
. $PSScriptRoot\scripts\FibreChannelConfig.ps1
. $PSScriptRoot\scripts\User.ps1
. $PSScriptRoot\scripts\Shelf.ps1
. $PSScriptRoot\scripts\ProtocolEndpoint.ps1
. $PSScriptRoot\scripts\FibreChannelInterface.ps1
. $PSScriptRoot\scripts\FibreChannelSession.ps1
. $PSScriptRoot\scripts\Array.ps1
. $PSScriptRoot\scripts\Alarm.ps1

Export-ModuleMember -Function Test-NS2PasswordFormat,   Test-Ns2Type,   Test-NS2ID,     Connect-NSGroup,  Disconnect-NSGroup,   IgnoreServerCertificate,
    New-NSVolumeCollection,    Get-NSVolumeCollection,    Set-NSVolumeCollection,    Remove-NSVolumeCollection,   
    Invoke-NSVolumeCollectionPromote,    Invoke-NSVolumeCollectionDemote,    Start-NSVolumeCollectionHandover,    Stop-NSVolumeCollectionHandover,   
    Test-NSVolumeCollection,    New-NSAccessControlRecord,    Get-NSAccessControlRecord,    Remove-NSAccessControlRecord,   
    New-NSToken,    Get-NSToken,    Remove-NSToken,    Get-NSTokenUserDetails,   
    New-NSUserGroup,    Get-NSUserGroup,    Set-NSUserGroup,    Remove-NSUserGroup,   
    New-NSChapUser,    Get-NSChapUser,    Set-NSChapUser,    Remove-NSChapUser,   
    New-NSWitness,    Get-NSWitness,    Remove-NSWitness,    Test-NSWitness,   
    New-NSPool,    Get-NSPool,    Set-NSPool,    Remove-NSPool,   
    Merge-NSPool,    Invoke-NSPoolDeDupe,    Get-NSFibreChannelInitiatorAlias,    New-NSProtectionTemplate,   
    Get-NSProtectionTemplate,    Set-NSProtectionTemplate,    Remove-NSProtectionTemplate,    New-NSInitiatorGroup,   
    Get-NSInitiatorGroup,    Set-NSInitiatorGroup,    Remove-NSInitiatorGroup,    Resolve-NSInitiatorGroupMerge,   
    Test-NSInitiatorGroupLunAvailability,    New-NSSnapshot,    Get-NSSnapshot,    Set-NSSnapshot,   
    Remove-NSSnapshot,    New-NSSnapshotBulk,    New-NSVolume,    Get-NSVolume,   
    Set-NSVolume,    Remove-NSVolume,    Restore-NSVolume,    Move-NSVolume,   
    Move-NSVolumeBulk,    Stop-NSVolumeMove,    Set-NSVolumeBulkDeDupe,    Set-NSVolumeBulkOnline,   
    New-NSActiveDirectoryMembership,    Get-NSActiveDirectoryMembership,    Set-NSActiveDirectoryMembership,    Remove-NSActiveDirectoryMembership,   
    Test-NSActiveDirectoryMembership,    Test-NSActiveDirectoryMembershipUser,    Test-NSActiveDirectoryMembershipGroup,    Get-NSSubnet,   
    Get-NSSpaceDomain,    Get-NSGroup,    Set-NSGroup,    Reset-NSGroup,   
    Stop-NSGroup,    Test-NSGroupAlert,    Test-NSGroupSoftwareUpdate,    Start-NSGroupSoftwareUpdate,   
    Start-NSGroupSoftwareDownload,    Stop-NSGroupSoftwareDownload,    Resume-NSGroupSoftwareUpdate,    Get-NSGroupDiscoveredList,   
    Test-NSGroupMerge,    Merge-NSGroup,    Get-NSGroupgetEULA,    Test-NSGroupMigrate,   
    Move-NSGroup,    Get-NSGroupTimeZoneList,    New-NSReplicationPartner,    Get-NSReplicationPartner,   
    Set-NSReplicationPartner,    Remove-NSReplicationPartner,    Suspend-NSReplicationPartner,    Resume-NSReplicationPartner,   
    Test-NSReplicationPartner,    New-NSFolder,    Get-NSFolder,    Set-NSFolder,   
    Remove-NSFolder,    Invoke-NSFolderDeDupe,    New-NSNetworkConfig,    Get-NSNetworkConfig,   
    Set-NSNetworkConfig,    Remove-NSNetworkConfig,    Initialize-NSNetworkConfig,    Test-NSNetworkConfig,   
    Get-NSController,    Stop-NSController,    Reset-NSController,    New-NSProtectionSchedule,   
    Get-NSProtectionSchedule,    Set-NSProtectionSchedule,    Remove-NSProtectionSchedule,    New-NSMasterKey,   
    Get-NSMasterKey,    Set-NSMasterKey,    Remove-NSMasterKey,    Clear-NSMasterKeyInactive,   
    Get-NSEvent,    New-NSApplicationServer,    Get-NSApplicationServer,    Set-NSApplicationServer,   
    Remove-NSApplicationServer,    Get-NSFibreChannelPort,    Get-NSApplicationCategory,    Get-NSAuditLog,   
    New-NSInitiator,    Get-NSInitiator,    Remove-NSInitiator,    Get-NSVersion,   
    New-NSPerformancePolicy,    Get-NSPerformancePolicy,    Set-NSPerformancePolicy,    Remove-NSPerformancePolicy,   
    Get-NSJob,    Get-NSDisk,    Set-NSDisk,    Get-NSNetworkInterface,   
    Get-NSUserPolicy,    Set-NSUserPolicy,    Get-NSSoftwareVersion,    New-NSSnapshotCollection,   
    Get-NSSnapshotCollection,    Set-NSSnapshotCollection,    Remove-NSSnapshotCollection,    Get-NSFibreChannelConfig,   
    Update-NSFibreChannelConfig,    Update-NSFibreChannelConfig,    New-NSUser,    Get-NSUser,   
    Set-NSUser,    Remove-NSUser,    Unlock-NSUser,    Get-NSShelf,   
    Set-NSShelf,    Show-NSShelf,    Get-NSProtocolEndpoint,    Get-NSFibreChannelInterface,   
    Set-NSFibreChannelInterface,    Get-NSFibreChannelSession,    New-NSArray,    Get-NSArray,   
    Set-NSArray,    Remove-NSArray,    Invoke-NSArray,    Stop-NSArray,   
    Reset-NSArray,    Get-NSAlarm,    Set-NSAlarm,    Remove-NSAlarm,   
    Clear-NSAlarm,    Undo-NSAlarm


# SIG # Begin signature block
# MIIeLgYJKoZIhvcNAQcCoIIeHzCCHhsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAmKfovwCHgf3WX
# 8+Y1MJPIzqCIORLSVe55ZGhaH1R7caCCGSUwggPuMIIDV6ADAgECAhB+k+v7fMZO
# WepLmnfUBvw7MA0GCSqGSIb3DQEBBQUAMIGLMQswCQYDVQQGEwJaQTEVMBMGA1UE
# CBMMV2VzdGVybiBDYXBlMRQwEgYDVQQHEwtEdXJiYW52aWxsZTEPMA0GA1UEChMG
# VGhhd3RlMR0wGwYDVQQLExRUaGF3dGUgQ2VydGlmaWNhdGlvbjEfMB0GA1UEAxMW
# VGhhd3RlIFRpbWVzdGFtcGluZyBDQTAeFw0xMjEyMjEwMDAwMDBaFw0yMDEyMzAy
# MzU5NTlaMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsayzSVRLlxwS
# CtgleZEiVypv3LgmxENza8K/LlBa+xTCdo5DASVDtKHiRfTot3vDdMwi17SUAAL3
# Te2/tLdEJGvNX0U70UTOQxJzF4KLabQry5kerHIbJk1xH7Ex3ftRYQJTpqr1SSwF
# eEWlL4nO55nn/oziVz89xpLcSvh7M+R5CvvwdYhBnP/FA1GZqtdsn5Nph2Upg4XC
# YBTEyMk7FNrAgfAfDXTekiKryvf7dHwn5vdKG3+nw54trorqpuaqJxZ9YfeYcRG8
# 4lChS+Vd+uUOpyyfqmUg09iW6Mh8pU5IRP8Z4kQHkgvXaISAXWp4ZEXNYEZ+VMET
# fMV58cnBcQIDAQABo4H6MIH3MB0GA1UdDgQWBBRfmvVuXMzMdJrU3X3vP9vsTIAu
# 3TAyBggrBgEFBQcBAQQmMCQwIgYIKwYBBQUHMAGGFmh0dHA6Ly9vY3NwLnRoYXd0
# ZS5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADA/BgNVHR8EODA2MDSgMqAwhi5odHRw
# Oi8vY3JsLnRoYXd0ZS5jb20vVGhhd3RlVGltZXN0YW1waW5nQ0EuY3JsMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIBBjAoBgNVHREEITAfpB0wGzEZ
# MBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMTANBgkqhkiG9w0BAQUFAAOBgQADCZuP
# ee9/WTCq72i1+uMJHbtPggZdN1+mUp8WjeockglEbvVt61h8MOj5aY0jcwsSb0ep
# rjkR+Cqxm7Aaw47rWZYArc4MTbLQMaYIXCp6/OJ6HVdMqGUY6XlAYiWWbsfHN2qD
# IQiOQerd2Vc/HXdJhyoWBl6mOGoiEqNRGYN+tjCCBKMwggOLoAMCAQICEA7P9DjI
# /r81bgTYapgbGlAwDQYJKoZIhvcNAQEFBQAwXjELMAkGA1UEBhMCVVMxHTAbBgNV
# BAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1l
# IFN0YW1waW5nIFNlcnZpY2VzIENBIC0gRzIwHhcNMTIxMDE4MDAwMDAwWhcNMjAx
# MjI5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29y
# cG9yYXRpb24xNDAyBgNVBAMTK1N5bWFudGVjIFRpbWUgU3RhbXBpbmcgU2Vydmlj
# ZXMgU2lnbmVyIC0gRzQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCi
# Yws5RLi7I6dESbsO/6HwYQpTk7CY260sD0rFbv+GPFNVDxXOBD8r/amWltm+YXkL
# W8lMhnbl4ENLIpXuwitDwZ/YaLSOQE/uhTi5EcUj8mRY8BUyb05Xoa6IpALXKh7N
# S+HdY9UXiTJbsF6ZWqidKFAOF+6W22E7RVEdzxJWC5JH/Kuu9mY9R6xwcueS51/N
# ELnEg2SUGb0lgOHo0iKl0LoCeqF3k1tlw+4XdLxBhircCEyMkoyRLZ53RB9o1qh0
# d9sOWzKLVoszvdljyEmdOsXF6jML0vGjG/SLvtmzV4s73gSneiKyJK4ux3DFvk6D
# Jgj7C72pT5kI4RAocqrNAgMBAAGjggFXMIIBUzAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIHgDBzBggrBgEFBQcBAQRn
# MGUwKgYIKwYBBQUHMAGGHmh0dHA6Ly90cy1vY3NwLndzLnN5bWFudGVjLmNvbTA3
# BggrBgEFBQcwAoYraHR0cDovL3RzLWFpYS53cy5zeW1hbnRlYy5jb20vdHNzLWNh
# LWcyLmNlcjA8BgNVHR8ENTAzMDGgL6AthitodHRwOi8vdHMtY3JsLndzLnN5bWFu
# dGVjLmNvbS90c3MtY2EtZzIuY3JsMCgGA1UdEQQhMB+kHTAbMRkwFwYDVQQDExBU
# aW1lU3RhbXAtMjA0OC0yMB0GA1UdDgQWBBRGxmmjDkoUHtVM2lJjFz9eNrwN5jAf
# BgNVHSMEGDAWgBRfmvVuXMzMdJrU3X3vP9vsTIAu3TANBgkqhkiG9w0BAQUFAAOC
# AQEAeDu0kSoATPCPYjA3eKOEJwdvGLLeJdyg1JQDqoZOJZ+aQAMc3c7jecshaAba
# tjK0bb/0LCZjM+RJZG0N5sNnDvcFpDVsfIkWxumy37Lp3SDGcQ/NlXTctlzevTcf
# Q3jmeLXNKAQgo6rxS8SIKZEOgNER/N1cdm5PXg5FRkFuDbDqOJqxOtoJcRD8HHm0
# gHusafT9nLYMFivxf1sJPZtb4hbKE4FtAC44DagpjyzhsvRaqQGvFZwsL0kb2yK7
# w/54lFHDhrGCiF3wPbRRoXkzKy57udwgCRNx62oZW8/opTBXLIlJP7nPf8m/PiJo
# Y1OavWl0rMUdPH+S4MO8HNgEdTCCBVEwggQ5oAMCAQICECqVMhjhC0t7b9FLKp7D
# DSYwDQYJKoZIhvcNAQELBQAwgb0xCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5WZXJp
# U2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgG
# A1UECxMxKGMpIDIwMDggVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXplZCB1
# c2Ugb25seTE4MDYGA1UEAxMvVmVyaVNpZ24gVW5pdmVyc2FsIFJvb3QgQ2VydGlm
# aWNhdGlvbiBBdXRob3JpdHkwHhcNMTYwNTEyMDAwMDAwWhcNMjYwNTExMjM1OTU5
# WjCBkTELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9u
# MR8wHQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMUIwQAYDVQQDEzlTeW1h
# bnRlYyBDbGFzcyAzIEV4dGVuZGVkIFZhbGlkYXRpb24gQ29kZSBTaWduaW5nIENB
# IC0gRzMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClkJSyzhW9r1AZ
# 4MTOCmjo+GgcPOUrzgtLV96hvRp2z8efNLEAbXj5JuXMmax0xp7gbOEtkSCTh2tu
# hGzVLlIX0I/Z6uz87CDyDdo/bZwl0dv7IOzw0P9LELa5ORGN9gyiTE+4Hfd90OXP
# 91wzgGak1iJve+N4FwYF9MbGlLf+y1Yqfg/6GPNIA02nbha3FRt93C/bQw4pHtF4
# b2gYG7eCy35Yj9jSmH+QTbvHCzxx/szEy/ajQhCsHcqD/JG+LKqAr7eZaUZx05Ug
# mc1RLpX4rBIefOK0ImkuC8AXfKD97VymLiIrZf99zTGkY6zfIuWTfKJOgsITLL8c
# iyI9q2btAgMBAAGjggF1MIIBcTAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUHMAGG
# Emh0dHA6Ly9zLnN5bWNkLmNvbTASBgNVHRMBAf8ECDAGAQH/AgEAMGAGA1UdIARZ
# MFcwVQYFZ4EMAQMwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9kLnN5bWNiLmNvbS9j
# cHMwJQYIKwYBBQUHAgIwGRoXaHR0cHM6Ly9kLnN5bWNiLmNvbS9ycGEwNgYDVR0f
# BC8wLTAroCmgJ4YlaHR0cDovL3Muc3ltY2IuY29tL3VuaXZlcnNhbC1yb290LmNy
# bDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDAzAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0R
# BCIwIKQeMBwxGjAYBgNVBAMTEVN5bWFudGVjUEtJLTItMzg4MB0GA1UdDgQWBBSr
# ixFJCyoCYnVKm8UCIKCE0kv43jAfBgNVHSMEGDAWgBS2d/ppSEefUxLVwuoHMnYH
# 0ZcHGTANBgkqhkiG9w0BAQsFAAOCAQEAMDGoEX4Zrh0009LXzLAcygGhShZfaMXK
# TQVZAfT8hQqnzx+wHCBkCUEYErTj3TIzcpkTK0hdSZYRIue5xG8FME1srDO+TU8i
# YtbxZyoWe8aMjg65lgCdDmQBkmTqN/gEfhFib4wsnF0LuP/df0DM6IjynSY0SbQf
# vflbP3hzLoH6aRrzlI+VMH7CtNiVJdJ6/oo46LBv9m858M76hFYQf1anxRRgtE9a
# OYFKrOEyYEsOFKD1HqFIQ5dZkb0daGaYMACLwlnUfvaFG3p/uttlaA6tbnO2VDn0
# aAOFfKG8U7M7oYI/eCQ1AqSuhYbCBeeAdVwFkXntqo2HaSaKF4HnwzCCBY0wggN1
# oAMCAQICCmEtI8sAAAAAACEwDQYJKoZIhvcNAQEFBQAwfzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UEAxMgTWljcm9zb2Z0IENvZGUg
# VmVyaWZpY2F0aW9uIFJvb3QwHhcNMTEwMjIyMTk0NjM5WhcNMjEwMjIyMTk1NjM5
# WjCBvTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYD
# VQQLExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwOCBW
# ZXJpU2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MTgwNgYDVQQD
# Ey9WZXJpU2lnbiBVbml2ZXJzYWwgUm9vdCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0
# eTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMdhN16xATTbYtcVm/9Y
# WowjI9ZgjpHXkJiDeuZYGTiMxfblZIW0onH77b252s1NALTILXOlx2lxlR85PLJE
# B5zoDvpNSsQh3ylhjzIiYYLFhx9ujHxfFiBRRNFwT1fq4xzjzHnuWNgOwrNFk8As
# 55oXK3sAN3pBM3jhM+LzEBp/hyy+9vX3QuLlv4diiV8AS9/F3eR1RDJBOh5xbmnL
# C3VGCNHK0iuV0M/7uUBrZIxXTfwTEXmE7V5U9jSfCAHzECUGF0ra8R16ZmuYYGak
# 2e/SLoLx8O8J6kTJFWriA24z06yfVQDH9ghqlLlf3OAz8YRg+VsnEbT8FvK7VmqA
# JY0CAwEAAaOByzCByDARBgNVHSAECjAIMAYGBFUdIAAwDwYDVR0TAQH/BAUwAwEB
# /zALBgNVHQ8EBAMCAYYwHQYDVR0OBBYEFLZ3+mlIR59TEtXC6gcydgfRlwcZMB8G
# A1UdIwQYMBaAFGL7CiFbf0NuEdoJVFBr9dKWcfGeMFUGA1UdHwROMEwwSqBIoEaG
# RGh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY3Jv
# c29mdENvZGVWZXJpZlJvb3QuY3JsMA0GCSqGSIb3DQEBBQUAA4ICAQBZR1KaNEM9
# sBPEMrj4N9lVUA0qpGdnM5TJ/9j1DKyNWjmDSG2yu0OPewvzW680ek+etwjn/gE4
# Ed4vO5w+lguyUILmtVW0YJYTSO0nLSUCcjiz82VZimIzdtVs+ZX0nTVMg6DBZ/yD
# tXaTxuhSG1m5uoWUCjvRKAUbGQzzIxdlRngO2XNKwLw9wEjhpPiH5RbhVodlOOEA
# F6IeRCv2T1opPLAbuF9lS0jrapgpXlfi9WLYQ0ezLmoTQad9OCMGDfdc5n+6zWUE
# klJSJmCoozwiDa23ukwyb1Leq5txyZ7ovp9epq13120llVYqGEPCzMFu4c7fRe/+
# t1EqfJi0/maDn2ts7HTVnzIfJDtDOtEEHQBKW6XSbWZMyMFN7MMBNcG4ef3gxvao
# KaCSjT1Dd3imHkzCOARY6zqDNATGNE4TRbJbci9yak/lGnwYa0TjyFgfjnEMgGtO
# K3s8+Erjk5LEsJq8pmG303zKcPX6/80HotnoEcxsRFCfcbCC0jamWXO9twtbaYZ7
# pR/HncHSCt0uTMIxtocqjRB6+qd+PF/wsKD1RQXeeRJ6AoXxHorTmYcXKVy+dVjW
# eQEGlWM5+wUWxz1JUaz6a5gtzJdurLPDb4KcAJZ/JA3pWUBhs2TbuflBobnu2ViN
# /wRXztj+6v9nW84T/Jz89uFmzaOg3XcRsjCCBaIwggSKoAMCAQICECgySelARPT/
# zK7u5NtdMXYwDQYJKoZIhvcNAQELBQAwgZExCzAJBgNVBAYTAlVTMR0wGwYDVQQK
# ExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1c3Qg
# TmV0d29yazFCMEAGA1UEAxM5U3ltYW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBWYWxp
# ZGF0aW9uIENvZGUgU2lnbmluZyBDQSAtIEczMB4XDTE4MTExOTAwMDAwMFoXDTIx
# MTExODIzNTk1OVowggEjMRMwEQYLKwYBBAGCNzwCAQMTAlVTMRkwFwYLKwYBBAGC
# NzwCAQIMCERlbGF3YXJlMRkwFwYLKwYBBAGCNzwCAQEMCFNhbiBKb3NlMR0wGwYD
# VQQPExRQcml2YXRlIE9yZ2FuaXphdGlvbjEQMA4GA1UEBRMHNTY5OTI2NTELMAkG
# A1UEBhMCVVMxEzARBgNVBAgMCkNhbGlmb3JuaWExETAPBgNVBAcMCFNhbiBKb3Nl
# MSswKQYDVQQKDCJIZXdsZXR0IFBhY2thcmQgRW50ZXJwcmlzZSBDb21wYW55MRYw
# FAYDVQQLDA1OaW1ibGVzdG9yYWdlMSswKQYDVQQDDCJIZXdsZXR0IFBhY2thcmQg
# RW50ZXJwcmlzZSBDb21wYW55MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEApZKrB2yQ1oxnRf02qfhEqvYFzXfVlTmlLcVbIEY9G6ZLawW0JNp+t1n2LXFA
# vR0Xcpw0cUUECeQz8iDj5Q05H9MiUAPuyycPE3F9gbTsZfE+YCWiCgjazoJZDWaY
# uNmgk8dwapwGyMq+f2zD85nVu46MH1I8GfTayHdLYvt0WeVDUu4kNhqwvQGU7PJ7
# 2V5LKy+rKEPAyxi/crvA2nIujGLsR7jP9kG6kxljctjwXtEyDpbZocrPOoNo/9fz
# ruYuod50HporzRpBjcLgxUV86qIsdAUgbv+BVrXpo7hTWrwcNRmzBHEh6JEw5oeN
# 7xVF2G1ZRTZT4JALj9FHHUYuwwIDAQABo4IBXzCCAVswCQYDVR0TBAIwADAOBgNV
# HQ8BAf8EBAMCB4AwKwYDVR0fBCQwIjAgoB6gHIYaaHR0cDovL3JoLnN5bWNiLmNv
# bS9yaC5jcmwwYAYDVR0gBFkwVzBVBgVngQwBAzBMMCMGCCsGAQUFBwIBFhdodHRw
# czovL2Quc3ltY2IuY29tL2NwczAlBggrBgEFBQcCAjAZDBdodHRwczovL2Quc3lt
# Y2IuY29tL3JwYTAWBgNVHSUBAf8EDDAKBggrBgEFBQcDAzAfBgNVHSMEGDAWgBSr
# ixFJCyoCYnVKm8UCIKCE0kv43jAdBgNVHQ4EFgQULA5bT8p6B+zgEwzg4yivfm+c
# 6NMwVwYIKwYBBQUHAQEESzBJMB8GCCsGAQUFBzABhhNodHRwOi8vcmguc3ltY2Qu
# Y29tMCYGCCsGAQUFBzAChhpodHRwOi8vcmguc3ltY2IuY29tL3JoLmNydDANBgkq
# hkiG9w0BAQsFAAOCAQEAcUxJyMwdcdcm/pxmPQrCHVSmHDYN+gsvmvN05h3S9Pw8
# fdZTdbB8myyqxTovG88hCVWPvnPvc+h6B0Ngs4fY1F/EwZi7D1G77g+8ESNakk55
# XePmszzK5tyAXq3CfqGQNsjkax9orswmCi9c6CXMq5XuYKQkwdvwsNOo8TqZP3MN
# RHthFpq+HFX1iKIKdTtEtl3sfC2Ym/KAX/GTImD5dihOiVDDtkS0FVtRJxtd0OYk
# 7QFalaWQAX6AyYgGVx2hnsC/B/gN1B2n4qIMpGUwVOCnR8nu7N9NkNg/7IRiy3/X
# A2MJq/DwSgAtqRpy3v9JH/HVY/SFHmoAun+ODiB2ojGCBF8wggRbAgEBMIGmMIGR
# MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAd
# BgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxQjBABgNVBAMTOVN5bWFudGVj
# IENsYXNzIDMgRXh0ZW5kZWQgVmFsaWRhdGlvbiBDb2RlIFNpZ25pbmcgQ0EgLSBH
# MwIQKDJJ6UBE9P/Mru7k210xdjANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcC
# AQwxAjAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsx
# DjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCppBwyOFGO+bJF1zlfcOoY
# 6i9Ss7iXftRV4hvp2/d4PzANBgkqhkiG9w0BAQEFAASCAQBQUnqZPJ/BMtCYTPDr
# Z3k1FxTcLWPLw68A0WrzOkYVXjMVb2CBD5+84uu2nDFPHOo/u54AWpa0M59N+NX2
# ViCGok0G21bfhl8HVBbBCTMrsFFVJEpeI1Q0JTyzqG2h875gLTMsKXsiOmpDNp08
# zWUxNDJWSyVPdxRORgBQ4WQRmie6ZRL1VrwdrVuznIXxEQC+MSyseTvHv479pA01
# k0FuigWuEQ9DpIqWfUsx2xEo27dVYzsa3Pod3yXfsA9jg0g1kRm7HRtyWTQX0Kbh
# Sk9OF9xdOWMrl0Xi6FYip6zxJFk55/DuReYXxI+axlpyWWnmQTVcuIxwnhjH+NCj
# T6ZMoYICCzCCAgcGCSqGSIb3DQEJBjGCAfgwggH0AgEBMHIwXjELMAkGA1UEBhMC
# VVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1h
# bnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIENBIC0gRzICEA7P9DjI/r81bgTY
# apgbGlAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJ
# KoZIhvcNAQkFMQ8XDTE5MDQwMTA1MTQzMlowIwYJKoZIhvcNAQkEMRYEFPmK83Mq
# VqR+Qt9ZbwtSeI7PdxJWMA0GCSqGSIb3DQEBAQUABIIBAAAQkfr+pP6/8nbNe9m0
# wfF4727/8jNgQUSaNE22yXm5CLoVoQiDlGzSSsBhUxcltsu3gZTO09vvVeG5gGs3
# ZATTshW+/eHlGEXJG50dbhldXzj/FIjrk0JiOyWvFfFWE1k2y7ck8/gdKrEazGYx
# b24FWuT8ebnkmuJlrC7Eq4Tf88NZDTJ7tutdXi0FcIY9WkkXJn0i6N+12PSs3qYJ
# vnU7282fVzF1MEt6YRE+xeBWw0oXMAcqTY0PfuW8tWuFC5bLcndbvqCj4DRhwPnS
# FoYY0MoWXp0UD0jbIBju7CFZhoUttEGb9ivyKZ/rIWrkPBRgHTVlq/s5Upz0NmXp
# 0SM=
# SIG # End signature block
