. $PSScriptRoot\scripts\helpers.ps1
. $PSScriptRoot\scripts\VolumeCollection.ps1
. $PSScriptRoot\scripts\AccessControlRecord.ps1
. $PSScriptRoot\scripts\Token.ps1
. $PSScriptRoot\scripts\UserGroup.ps1
. $PSScriptRoot\scripts\ChapUser.ps1
. $PSScriptRoot\scripts\Pool.ps1
. $PSScriptRoot\scripts\FibreChannelInitiatorAlias.ps1
. $PSScriptRoot\scripts\ProtectionTemplate.ps1
. $PSScriptRoot\scripts\InitiatorGroup.ps1
. $PSScriptRoot\scripts\Snapshot.ps1
. $PSScriptRoot\scripts\Volume.ps1
. $PSScriptRoot\scripts\ActiveDirectoryMembership.ps1
. $PSScriptRoot\scripts\Subnet.ps1
. $PSScriptRoot\scripts\SpaceDomain.ps1
. $PSScriptRoot\scripts\Group.ps1
. $PSScriptRoot\scripts\ReplicationPartner.ps1
. $PSScriptRoot\scripts\Folder.ps1
. $PSScriptRoot\scripts\NetworkConfig.ps1
. $PSScriptRoot\scripts\Controller.ps1
. $PSScriptRoot\scripts\ProtectionSchedule.ps1
. $PSScriptRoot\scripts\MasterKey.ps1
. $PSScriptRoot\scripts\ApplicationServer.ps1
. $PSScriptRoot\scripts\Event.ps1
. $PSScriptRoot\scripts\FibreChannelPort.ps1
. $PSScriptRoot\scripts\ApplicationCategory.ps1
. $PSScriptRoot\scripts\AuditLog.ps1
. $PSScriptRoot\scripts\Initiator.ps1
. $PSScriptRoot\scripts\Version.ps1
. $PSScriptRoot\scripts\PerformancePolicy.ps1
. $PSScriptRoot\scripts\Job.ps1
. $PSScriptRoot\scripts\Disk.ps1
. $PSScriptRoot\scripts\NetworkInterface.ps1
. $PSScriptRoot\scripts\SoftwareVersion.ps1
. $PSScriptRoot\scripts\SnapshotCollection.ps1
. $PSScriptRoot\scripts\FibreChannelConfig.ps1
. $PSScriptRoot\scripts\User.ps1
. $PSScriptRoot\scripts\Shelf.ps1
. $PSScriptRoot\scripts\ProtocolEndpoint.ps1
. $PSScriptRoot\scripts\FibreChannelInterface.ps1
. $PSScriptRoot\scripts\FibreChannelSession.ps1
. $PSScriptRoot\scripts\Array.ps1
. $PSScriptRoot\scripts\Alarm.ps1

Export-ModuleMember -Function Test-NS2PasswordFormat,   Test-Ns2Type,   Test-NS2ID,     Connect-NSGroup,  Disconnect-NSGroup,   IgnoreServerCertificate,
    New-NSVolumeCollection,    Get-NSVolumeCollection,    Set-NSVolumeCollection,    Remove-NSVolumeCollection,   
    Invoke-NSVolumeCollectionPromote,    Invoke-NSVolumeCollectionDemote,    Start-NSVolumeCollectionHandover,    Stop-NSVolumeCollectionHandover,   
    Test-NSVolumeCollection,    New-NSAccessControlRecord,    Get-NSAccessControlRecord,    Remove-NSAccessControlRecord,   
    New-NSToken,    Get-NSToken,    Remove-NSToken,    Get-NSTokenUserDetails,   
    New-NSUserGroup,    Get-NSUserGroup,    Set-NSUserGroup,    Remove-NSUserGroup,   
    New-NSChapUser,    Get-NSChapUser,    Set-NSChapUser,    Remove-NSChapUser,   
    New-NSPool,    Get-NSPool,    Set-NSPool,    Remove-NSPool,   
    Merge-NSPool,    Invoke-NSPoolDeDupe,    Get-NSFibreChannelInitiatorAlias,    New-NSProtectionTemplate,   
    Get-NSProtectionTemplate,    Set-NSProtectionTemplate,    Remove-NSProtectionTemplate,    New-NSInitiatorGroup,   
    Get-NSInitiatorGroup,    Set-NSInitiatorGroup,    Remove-NSInitiatorGroup,    Resolve-NSInitiatorGroupMerge,   
    Test-NSInitiatorGroupLunAvailability,    New-NSSnapshot,    Get-NSSnapshot,    Set-NSSnapshot,   
    Remove-NSSnapshot,    New-NSSnapshotBulk,    New-NSVolume,    Get-NSVolume,   
    Set-NSVolume,    Remove-NSVolume,    Restore-NSVolume,    Move-NSVolume,   
    Move-NSVolumeBulk,    Stop-NSVolumeMove,    Set-NSVolumeBulkDeDupe,    Set-NSVolumeBulkOnline,   
    New-NSActiveDirectoryMembership,    Get-NSActiveDirectoryMembership,    Set-NSActiveDirectoryMembership,    Remove-NSActiveDirectoryMembership,   
    Test-NSActiveDirectoryMembership,    Test-NSActiveDirectoryMembershipUser,    Test-NSActiveDirectoryMembershipGroup,    Get-NSSubnet,   
    Get-NSSpaceDomain,    Get-NSGroup,    Set-NSGroup,    Stop-NSGroup,   
    Test-NSGroupAlert,    Test-NSGroupSoftwareUpdate,    Start-NSGroupSoftwareUpdate,    Start-NSGroupSoftwareDownload,   
    Abort-NSGroupSoftwareDownload,    Resume-NSGroupSoftwareUpdate,    Get-NSGroupDiscoveredList,    Test-NSGroupMerge,   
    Merge-NSGroup,    Get-NSGroupgetEULA,    New-NSReplicationPartner,    Get-NSReplicationPartner,   
    Set-NSReplicationPartner,    Remove-NSReplicationPartner,    Suspend-NSReplicationPartner,    Resume-NSReplicationPartner,   
    Test-NSReplicationPartner,    New-NSFolder,    Get-NSFolder,    Set-NSFolder,   
    Remove-NSFolder,    Invoke-NSFolderDeDupe,    New-NSNetworkConfig,    Get-NSNetworkConfig,   
    Set-NSNetworkConfig,    Remove-NSNetworkConfig,    Initialize-NSNetworkConfig,    Test-NSNetworkConfig,   
    Get-NSController,    Stop-NSController,    Reset-NSController,    New-NSProtectionSchedule,   
    Get-NSProtectionSchedule,    Set-NSProtectionSchedule,    Remove-NSProtectionSchedule,    New-NSMasterKey,   
    Get-NSMasterKey,    Set-NSMasterKey,    Remove-NSMasterKey,    New-NSApplicationServer,   
    Get-NSApplicationServer,    Set-NSApplicationServer,    Remove-NSApplicationServer,    Get-NSEvent,   
    Get-NSFibreChannelPort,    Get-NSApplicationCategory,    Get-NSAuditLog,    New-NSInitiator,   
    Get-NSInitiator,    Remove-NSInitiator,    Get-NSVersion,    New-NSPerformancePolicy,   
    Get-NSPerformancePolicy,    Set-NSPerformancePolicy,    Remove-NSPerformancePolicy,    Get-NSJob,   
    Get-NSDisk,    Set-NSDisk,    Get-NSNetworkInterface,    Get-NSSoftwareVersion,   
    New-NSSnapshotCollection,    Get-NSSnapshotCollection,    Set-NSSnapshotCollection,    Remove-NSSnapshotCollection,   
    Get-NSFibreChannelConfig,    Update-NSFibreChannelConfig,    Upgrade-NSFibreChannelConfig,    New-NSUser,   
    Get-NSUser,    Set-NSUser,    Remove-NSUser,    Get-NSShelf,   
    Set-NSShelf,    ERROR-NSShelf,    Get-NSProtocolEndpoint,    Get-NSFibreChannelInterface,   
    Set-NSFibreChannelInterface,    Get-NSFibreChannelSession,    New-NSArray,    Get-NSArray,   
    Set-NSArray,    Remove-NSArray,    Invoke-NSArray,    Stop-NSArray,   
    Reset-NSArray,    Get-NSAlarm,    Set-NSAlarm,    Remove-NSAlarm,   
    Clear-NSAlarm,    Undo-NSAlarm


# SIG # Begin signature block
# MIIeJQYJKoZIhvcNAQcCoIIeFjCCHhICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBxB0CqM/WBNW+e
# 3gt86SSkmH+iSMAqvzld0ILCqZwBiaCCGRwwggPuMIIDV6ADAgECAhB+k+v7fMZO
# WepLmnfUBvw7MA0GCSqGSIb3DQEBBQUAMIGLMQswCQYDVQQGEwJaQTEVMBMGA1UE
# CBMMV2VzdGVybiBDYXBlMRQwEgYDVQQHEwtEdXJiYW52aWxsZTEPMA0GA1UEChMG
# VGhhd3RlMR0wGwYDVQQLExRUaGF3dGUgQ2VydGlmaWNhdGlvbjEfMB0GA1UEAxMW
# VGhhd3RlIFRpbWVzdGFtcGluZyBDQTAeFw0xMjEyMjEwMDAwMDBaFw0yMDEyMzAy
# MzU5NTlaMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsayzSVRLlxwS
# CtgleZEiVypv3LgmxENza8K/LlBa+xTCdo5DASVDtKHiRfTot3vDdMwi17SUAAL3
# Te2/tLdEJGvNX0U70UTOQxJzF4KLabQry5kerHIbJk1xH7Ex3ftRYQJTpqr1SSwF
# eEWlL4nO55nn/oziVz89xpLcSvh7M+R5CvvwdYhBnP/FA1GZqtdsn5Nph2Upg4XC
# YBTEyMk7FNrAgfAfDXTekiKryvf7dHwn5vdKG3+nw54trorqpuaqJxZ9YfeYcRG8
# 4lChS+Vd+uUOpyyfqmUg09iW6Mh8pU5IRP8Z4kQHkgvXaISAXWp4ZEXNYEZ+VMET
# fMV58cnBcQIDAQABo4H6MIH3MB0GA1UdDgQWBBRfmvVuXMzMdJrU3X3vP9vsTIAu
# 3TAyBggrBgEFBQcBAQQmMCQwIgYIKwYBBQUHMAGGFmh0dHA6Ly9vY3NwLnRoYXd0
# ZS5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADA/BgNVHR8EODA2MDSgMqAwhi5odHRw
# Oi8vY3JsLnRoYXd0ZS5jb20vVGhhd3RlVGltZXN0YW1waW5nQ0EuY3JsMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIBBjAoBgNVHREEITAfpB0wGzEZ
# MBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMTANBgkqhkiG9w0BAQUFAAOBgQADCZuP
# ee9/WTCq72i1+uMJHbtPggZdN1+mUp8WjeockglEbvVt61h8MOj5aY0jcwsSb0ep
# rjkR+Cqxm7Aaw47rWZYArc4MTbLQMaYIXCp6/OJ6HVdMqGUY6XlAYiWWbsfHN2qD
# IQiOQerd2Vc/HXdJhyoWBl6mOGoiEqNRGYN+tjCCBKMwggOLoAMCAQICEA7P9DjI
# /r81bgTYapgbGlAwDQYJKoZIhvcNAQEFBQAwXjELMAkGA1UEBhMCVVMxHTAbBgNV
# BAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1l
# IFN0YW1waW5nIFNlcnZpY2VzIENBIC0gRzIwHhcNMTIxMDE4MDAwMDAwWhcNMjAx
# MjI5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29y
# cG9yYXRpb24xNDAyBgNVBAMTK1N5bWFudGVjIFRpbWUgU3RhbXBpbmcgU2Vydmlj
# ZXMgU2lnbmVyIC0gRzQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCi
# Yws5RLi7I6dESbsO/6HwYQpTk7CY260sD0rFbv+GPFNVDxXOBD8r/amWltm+YXkL
# W8lMhnbl4ENLIpXuwitDwZ/YaLSOQE/uhTi5EcUj8mRY8BUyb05Xoa6IpALXKh7N
# S+HdY9UXiTJbsF6ZWqidKFAOF+6W22E7RVEdzxJWC5JH/Kuu9mY9R6xwcueS51/N
# ELnEg2SUGb0lgOHo0iKl0LoCeqF3k1tlw+4XdLxBhircCEyMkoyRLZ53RB9o1qh0
# d9sOWzKLVoszvdljyEmdOsXF6jML0vGjG/SLvtmzV4s73gSneiKyJK4ux3DFvk6D
# Jgj7C72pT5kI4RAocqrNAgMBAAGjggFXMIIBUzAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIHgDBzBggrBgEFBQcBAQRn
# MGUwKgYIKwYBBQUHMAGGHmh0dHA6Ly90cy1vY3NwLndzLnN5bWFudGVjLmNvbTA3
# BggrBgEFBQcwAoYraHR0cDovL3RzLWFpYS53cy5zeW1hbnRlYy5jb20vdHNzLWNh
# LWcyLmNlcjA8BgNVHR8ENTAzMDGgL6AthitodHRwOi8vdHMtY3JsLndzLnN5bWFu
# dGVjLmNvbS90c3MtY2EtZzIuY3JsMCgGA1UdEQQhMB+kHTAbMRkwFwYDVQQDExBU
# aW1lU3RhbXAtMjA0OC0yMB0GA1UdDgQWBBRGxmmjDkoUHtVM2lJjFz9eNrwN5jAf
# BgNVHSMEGDAWgBRfmvVuXMzMdJrU3X3vP9vsTIAu3TANBgkqhkiG9w0BAQUFAAOC
# AQEAeDu0kSoATPCPYjA3eKOEJwdvGLLeJdyg1JQDqoZOJZ+aQAMc3c7jecshaAba
# tjK0bb/0LCZjM+RJZG0N5sNnDvcFpDVsfIkWxumy37Lp3SDGcQ/NlXTctlzevTcf
# Q3jmeLXNKAQgo6rxS8SIKZEOgNER/N1cdm5PXg5FRkFuDbDqOJqxOtoJcRD8HHm0
# gHusafT9nLYMFivxf1sJPZtb4hbKE4FtAC44DagpjyzhsvRaqQGvFZwsL0kb2yK7
# w/54lFHDhrGCiF3wPbRRoXkzKy57udwgCRNx62oZW8/opTBXLIlJP7nPf8m/PiJo
# Y1OavWl0rMUdPH+S4MO8HNgEdTCCBVYwggQ+oAMCAQICEBkaMst1nJe4z6wRjdUS
# f0kwDQYJKoZIhvcNAQELBQAwgcoxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5WZXJp
# U2lnbiwgSW5jLjEfMB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgG
# A1UECxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXplZCB1
# c2Ugb25seTFFMEMGA1UEAxM8VmVyaVNpZ24gQ2xhc3MgMyBQdWJsaWMgUHJpbWFy
# eSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4XDTE0MDMwNDAwMDAwMFoX
# DTI0MDMwMzIzNTk1OVowgZExCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRl
# YyBDb3Jwb3JhdGlvbjEfMB0GA1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFC
# MEAGA1UEAxM5U3ltYW50ZWMgQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIENv
# ZGUgU2lnbmluZyBDQSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEA0BgC7u2ijQhYYw8m190ie4j25MfsOyYYeNPHpCBTjYN8pT9+pcgrR98N9abZ
# wx0lk2DPfNzqAyy+eH9cSG2nAtlJ+KHr65phfJ/AJtbcFdi4EHwgul70KPao6qdc
# fMackJA0PLYirP66DDoe1l6Etlvwo4FweIqNRlJ7/NtJ8ykTEXRPjRazwuOgLccD
# BJ3Mw3LhDgz7Ao7xJhd7bq74tzOLpmFLRd/yJUTH97CYIzbcKHkK6JtyiKjY6K57
# fwpkRaXwV5KadwZFHuuf6Gbzen2SgV8ALR649lYTWmINt0ehj3Lvg16C4JSY4ayl
# rYY34KfTurE+eutFqPHBRH3iAwIDAQABo4IBbTCCAWkwEgYDVR0TAQH/BAgwBgEB
# /wIBADAvBgNVHR8EKDAmMCSgIqAghh5odHRwOi8vcy5zeW1jYi5jb20vcGNhMy1n
# NS5jcmwwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwDgYDVR0PAQH/BAQDAgEGMC4G
# CCsGAQUFBwEBBCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL3Muc3ltY2QuY29tMF8G
# A1UdIARYMFYwVAYEVR0gADBMMCMGCCsGAQUFBwIBFhdodHRwczovL2Quc3ltY2Iu
# Y29tL2NwczAlBggrBgEFBQcCAjAZGhdodHRwczovL2Quc3ltY2IuY29tL3JwYTAp
# BgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS02MjkwHQYDVR0O
# BBYEFBZm3ko041CnEYYDsWypxqzNWW6bMB8GA1UdIwQYMBaAFH/TZafC3ey78DAJ
# 80M5+gKvMzEzMA0GCSqGSIb3DQEBCwUAA4IBAQA/Wxnz+hPVdTgqWu6fWqBMqR3F
# zJTu3hX+9RBupBulZINUGFjECyihhcNOdOX/iXz+1e08unGfVgImjxYqiP6woyci
# zkviOI4ApjqGX53lPqjeZElBdEEh/QfIhBfaHWUwgssmTznWBCekgbFLScMji34C
# Mhgnt6sL8xhytqTuZwZvOKZYjeDxfl2kYMao5VBf4Oi64o+ZWLa1oKh28aLxHIhB
# cn5Sl5sKNpmNUPcB6zzn8CJq5TWMYzaKGrHZZ2ZflxrvqCCd8C+6bM7ZlIUA8Vjx
# fcl8IrUHXQLG5gu/q5OT/ycYjjM2flc08cOvBMGE8Vaz6IeDNvjTCjHcbixtMIIF
# hzCCBG+gAwIBAgIQcrt012ZtMxP3K/ddOCgjEDANBgkqhkiG9w0BAQsFADCBkTEL
# MAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYD
# VQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMUIwQAYDVQQDEzlTeW1hbnRlYyBD
# bGFzcyAzIEV4dGVuZGVkIFZhbGlkYXRpb24gQ29kZSBTaWduaW5nIENBIC0gRzIw
# HhcNMTYwMTA2MDAwMDAwWhcNMTgxMjE0MjM1OTU5WjCB0jETMBEGCysGAQQBgjc8
# AgEDEwJVUzEZMBcGCysGAQQBgjc8AgECEwhEZWxhd2FyZTEdMBsGA1UEDxMUUHJp
# dmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzQ0NTQyMTExCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIDApDYWxpZm9ybmlhMREwDwYDVQQHDAhzYW4gam9zZTEcMBoGA1UE
# CgwTTmltYmxlIFN0b3JhZ2UsIEluYzEcMBoGA1UEAxQTTmltYmxlIFN0b3JhZ2Us
# IEluYzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMlEMhPX3V1qcCgU
# jLB6CaX2+M/cX482dOx+NKV27bLGKsDyH0bPIPSpRrGRcWt4Zsuy6bC0tDZUzd/u
# 3En23j8YmuUYMSwPprlzopPvzFSdAZEfv52O0pZJYoulLBceMQ+kusT6haSY9LX/
# Xhs/TIsyMoFgmvjPgYmTkxg0XpmPs/DkQCeotNQinSHEosjEDCiwtHTlnZ0y00Ra
# ggnDz5uusR9zIcJ4/DFsicldFRZNWgeAgyGC8nYPVR37aWVhOgW/9B+aZgBwehmv
# /uxYveBGXDjJAbuhjvB/3SFWHZF7shcOgr8JRugDXLG6PsW9Cw5oPB9tiet1arPJ
# CLPQKrkCAwEAAaOCAZYwggGSMC4GA1UdEQQnMCWgIwYIKwYBBQUHCAOgFzAVDBNV
# Uy1ERUxBV0FSRS00NDU0MjExMAkGA1UdEwQCMAAwDgYDVR0PAQH/BAQDAgeAMCsG
# A1UdHwQkMCIwIKAeoByGGmh0dHA6Ly9zdy5zeW1jYi5jb20vc3cuY3JsMGYGA1Ud
# IARfMF0wWwYLYIZIAYb4RQEHFwYwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9kLnN5
# bWNiLmNvbS9jcHMwJQYIKwYBBQUHAgIwGQwXaHR0cHM6Ly9kLnN5bWNiLmNvbS9y
# cGEwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwMwHwYDVR0jBBgwFoAUFmbeSjTjUKcR
# hgOxbKnGrM1ZbpswHQYDVR0OBBYEFKbP5OH5f/KNGe7kE5MEpVUZcv6ZMFgGCCsG
# AQUFBwEBBEwwSjAfBggrBgEFBQcwAYYTaHR0cDovL3N3LnN5bWNkLmNvbTAnBggr
# BgEFBQcwAoYbaHR0cDovL3N3MS5zeW1jYi5jb20vc3cuY3J0MA0GCSqGSIb3DQEB
# CwUAA4IBAQA/fxuOME6OOe4GPKYU8FpY8/CNVbWU/OBXNCu/iqkt0j3mECRt9crd
# 2T6bz912plg46NQIl9OH7alHGxdxdUcP6V71IUs7MWqEZxWOckUBwaMOfPKRfBvJ
# De8IM8YcLyAW5YPEBhyorYTk/l/swNvldeZ7EcGfJmJiGXwTMvtcVsne+whDGq0P
# oahjQfkSausMBBNYWpjMtL+KSs8kJRviHMYB/Sc3ugI8Nzh6J9TXD4ILpBUnfCJM
# jJ7qZj8eYjU8F+7BCYrRsGu1BOI7w8+5gzGFzM+LAy5UEUQ+VY7HjDprTUgPJsQA
# Aa6+e7lc7ypx0NAyUuy9akjtqLxcsRlWMIIFmjCCA4KgAwIBAgIKYRmT5AAAAAAA
# HDANBgkqhkiG9w0BAQUFADB/MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSkwJwYDVQQDEyBNaWNyb3NvZnQgQ29kZSBWZXJpZmljYXRpb24gUm9v
# dDAeFw0xMTAyMjIxOTI1MTdaFw0yMTAyMjIxOTM1MTdaMIHKMQswCQYDVQQGEwJV
# UzEXMBUGA1UEChMOVmVyaVNpZ24sIEluYy4xHzAdBgNVBAsTFlZlcmlTaWduIFRy
# dXN0IE5ldHdvcmsxOjA4BgNVBAsTMShjKSAyMDA2IFZlcmlTaWduLCBJbmMuIC0g
# Rm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxRTBDBgNVBAMTPFZlcmlTaWduIENsYXNz
# IDMgUHVibGljIFByaW1hcnkgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHNTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK8kCAgpejWeYAyq50s7Ttx8
# vDxFHLsr4P4pAvlXCKNkhRUn9fGtyDGJXSLoKqqmQrOP+LlVt7G3S7P+j34HV+zv
# Q9tmYhVhz2ANpNje+ODDYgg9VBPrScpZVIUm5SuPG5/r9aGRwjNJ2ENjalJL0o/o
# cFFN0Ylpe8dw9rPcEnTbe11LVtOWvxV3obD0oiXyrxySZxjl9AYE75C55ADk3Tq1
# Gf8CuvQ87uCL6zeL7PTXrPL28D2v3XWRMxkdHEDLdCQZIZPZFP6sKlLHj9UESeSN
# Y0eIPGmDy/5HvSt+T8WVrg6d1NFDwGdz4xQIfuU/n3O4MwrPXT80h5aK7lPoJRUC
# AwEAAaOByzCByDARBgNVHSAECjAIMAYGBFUdIAAwDwYDVR0TAQH/BAUwAwEB/zAL
# BgNVHQ8EBAMCAYYwHQYDVR0OBBYEFH/TZafC3ey78DAJ80M5+gKvMzEzMB8GA1Ud
# IwQYMBaAFGL7CiFbf0NuEdoJVFBr9dKWcfGeMFUGA1UdHwROMEwwSqBIoEaGRGh0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY3Jvc29m
# dENvZGVWZXJpZlJvb3QuY3JsMA0GCSqGSIb3DQEBBQUAA4ICAQCBKoIWjDRnK+UD
# 6zR7jKKjUIr0VYbxHoyOrn3uAxnOcpUYSK1iEf0g/T9HBgFa4uBvjBUsTjxqUGwL
# NqPPeg2cQrxc+BnVYONp5uIjQWeMaIN2K4+Toyq1f75Z+6nJsiaPyqLzghuYPpGV
# J5eGYe5bXQdrzYao4mWAqOIV4rK+IwVqugzzR5NNrKSMB3k5wGESOgUNiaPsn1eJ
# hPvsynxHZhSR2LYPGV3muEqsvEfIcUOW5jIgpdx3hv0844tx23ubA/y3HTJk6xZS
# oEOj+i6tWZJOfMfyM0JIOFE6fDjHGyQiKEAeGkYfF9sY9/AnNWy4Y9nNuWRdK6Ve
# 78YptPLH+CHMBLpX/QG2q8Zn+efTmX/09SL6cvX9/zocQjqh+YAYpe6NHNRmnkUB
# /qru//sXjzD38c0pxZ3stdVJAD2FuMu7kzonaknAMK5myfcjKDJ2+aSDVshIzlqW
# qqDMDMR/tI6Xr23jVCfDn4bA1uRzCJcF29BUYl4DSMLVn3+nZozQnbBP1NOYX0t6
# yX+yKVLQEoDHD1S2HmfNxqBsEQOE00h15yr+sDtuCjqma3aZBaPxd2hhMxRHBvxT
# f1K9khRcSiRqZ4yvjZCq0PZ5IRuTJnzDzh69iDiSrkXGGWpJULMF+K5ZN4pqJQOU
# sVmBUOi6g4C3IzX0drlnHVkYrSCNlDGCBF8wggRbAgEBMIGmMIGRMQswCQYDVQQG
# EwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5
# bWFudGVjIFRydXN0IE5ldHdvcmsxQjBABgNVBAMTOVN5bWFudGVjIENsYXNzIDMg
# RXh0ZW5kZWQgVmFsaWRhdGlvbiBDb2RlIFNpZ25pbmcgQ0EgLSBHMgIQcrt012Zt
# MxP3K/ddOCgjEDANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkG
# CSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEE
# AYI3AgEVMC8GCSqGSIb3DQEJBDEiBCDhhOHldtIDKSfwq6+r4g6OerhdKa5jjU4w
# +0p2Xqj6nDANBgkqhkiG9w0BAQEFAASCAQBEu+l7gI+HW3YCvKk/1DAbRAlXgFNk
# ubhbNyDaa0+Xjhu0veKjtsAS/HkvoBnumKOP9Nu3daw+uJqcb2BGfg074hrt7L4N
# LwliC57omSTomYeT6Fbd85sz9InT3vpXuF3dfAUu4iiCRW6DUOxBnKxmjHFtjZvl
# N9DgT4L/rx5+1pgZtSmZSSk4iqJ+r0lBu20Rk/6kS3u5W3C8cMdOQQ46sbHtwrV8
# UtH4EGUxYHZS00vccAy62/VvkxPo1W4FH0cHsuKFYTehTLLzQk+hDzSsv/mx+Mv5
# 5Mt3HLOzURpDO7ro1KTOfA9UomBGrs0hVqOD5BafkFiTLp4d1OduTneloYICCzCC
# AgcGCSqGSIb3DQEJBjGCAfgwggH0AgEBMHIwXjELMAkGA1UEBhMCVVMxHTAbBgNV
# BAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1l
# IFN0YW1waW5nIFNlcnZpY2VzIENBIC0gRzICEA7P9DjI/r81bgTYapgbGlAwCQYF
# Kw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkF
# MQ8XDTE4MDkxMDE3NDUzNVowIwYJKoZIhvcNAQkEMRYEFJW04nP2WMgRPumFJUm0
# S7WOWNxVMA0GCSqGSIb3DQEBAQUABIIBABQQtr3lbZngWxQcI6Kl9mTRdsH/l6Uu
# GYaAjSW6rkzUaZcohmTEhiJKsYScztja2GL5nLV84CS+s8ztG1yUM6OipDGoNXhg
# 8hPb1BQ465wcV2r9QbvsX0rKARM5XFHhbe2LH5AZT1KFuvuYWFcPBr9YLOJKPwZY
# ng82cUl08NfORzltpGpOof14agJU3Igr9q/q1Hrf/PblIoBH+iGjQL05Ztk9Ti6y
# n1mzCBn1pL9Idf8Qrd7bJztFEazSUFHx5k1XDUeiPNqoFYsnISx8EeF0NGMc/B6z
# kifLqV60YZmyEjp7gBhAUYGshG76Gp2xVs/P28rxMyVFdsPxCP8Ax8M=
# SIG # End signature block
