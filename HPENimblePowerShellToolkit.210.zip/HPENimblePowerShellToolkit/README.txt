HPE Nimble Storage PowerShell Toolkit 2.1.0 ReadMe
==================================================

To install the HPE Nimble Storage Powershell Toolkit:

1. Right-click on the original downloaded ZIP file. Choose 'Unblock' to download the file if it
   has the blocked property set.

2. Unzip the file into the following location:

	C:\Windows\System32\WindowsPowerShell\v1\Modules\
	
3. Verify that HPENimblePowerShellToolkit.psd1 exists in the following location:

	C:\Windows\System32\WindowsPowerShell\v1\Modules\HPENimblePowerShellToolkit\HPENimblePowerShellToolkit.psd1
	

To use the HPE Nimble Storage PowerShell Toolkit:

1. From a PowerShell prompt, import the HPE Nimble Storage PowerShell module by running the following command:

	PS:> Import-Module HPENimblePowerShellToolkit

2. Connect to an existing Nimble Group using one of the following commands:

	PS:> Connect-NSGroup -group 192.168.1.50 -credential Username -ImportServerCertificate
		-or-	
	PS:> Connect-NSGroup -group 192.168.1.50 -credential Username -IgnoreServerCertificate
	
	A pop-up box appears that prompts you for your password.
	
	If you choose to use the '-ImportServerCertificate' option, it need only be done the first time you connect 
	to the array. The import process will require an Administrative PowerShell Window. 

Getting help with the HPE Nimble Storage PowerShell Toolkit:

1. To get a complete list of PowerShell commands, run the following command:

	PS:> get-command -module HPENimblePowerShellToolkit
	
2. To get detailed help about a single command, run Get-Help with the name of the command, as shown
   in the following examples:

	PS:> get-help new-NSVolume
	PS:> get-help new-NSVolume -full
	PS:> get-help new-NSVolume -examples

	
Tips and Tricks:
------------------------------------------------------------------------------------------------------------------------
The PowerShell toolkit and the HPE Nimble Storage API use a common ID number as the way to uniquely identify an object 
such as a volume or an initiator group. Many commands, such as Set-NSVolume, expect you to identify the object to be acted on. This number can be hard to transcribe manually. You may find it useful to embed a "get-ns" type command in your 
"set-ns" type command. As an example, if you wanted to modify a volume named "MyTestVolume", you could use the following set
of commands:

	$MyID = $(get-nsvolume -name "MyTestVolume").id
	set-nsvolume -id $MyID -description "This is My Test Volume"

Alternately, if you wanted to issue this same command from a single line, you could use the following:

	set-nsvolume -id $(get-nsvolume -name "MyTestVolume").id -description "My Test Volume"


